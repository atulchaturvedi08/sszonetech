var controller = new ScrollMagic.Controller();

function createScrollScene(sectionId, animationProps) {
    var animation = gsap.timeline().from(`${sectionId} .animate__animated`, animationProps);

    var scene = new ScrollMagic.Scene({
        triggerElement: sectionId,
        triggerHook: 0.8,
        reverse: false
    })
    .setTween(animation)
    .addTo(controller);
}

createScrollScene("#myCarousel", {
     opacity: 0,
     y: 100,
     scale: 0, 
     duration: 1,
});

createScrollScene("#vertical", {
     opacity: 0, 
     x: -100, 
     scale: 0, 
     duration: 1, 
});

createScrollScene("#Catregories", {
     opacity: 0, 
     x: -100, 
     scale: 0, 
     duration: 1,
});

createScrollScene("#new-releaes", {
     opacity: 0, 
     x: -100, 
     duration: 1, 
});
createScrollScene("#big-deals", {
     opacity: 0, 
     x: -100, 
     duration: 1, 
});

createScrollScene("#pupular-product", {
     opacity: 0, 
     x: -100, 
     scale: 0, 
     duration: 1, 
});

createScrollScene("#image", {
     opacity: 0, 
     x: -100, 
     scale: 0, 
     duration: 1, 
});

createScrollScene("#Catch", {
     opacity: 0, 
     scale: 0, 
     duration: 1, 
});

createScrollScene("#Arrivals", {
     opacity: 0, 
     scale: 0, 
     duration: 1, 
});

createScrollScene("#Arrivals1", {
     opacity: 0, 
     y: 100, 
     duration: 1, 
});

createScrollScene("#Arrivals2", {
     opacity: 0, 
     y: 100, 
     scale: 0, 
     duration: 1, 
});

createScrollScene("#Arrivals3", {
     opacity: 0, 
     y: 100, 
     scale: 0, 
     duration: 1, 
});

createScrollScene("#card1", {
     opacity: 0, 
     y: 100, 
     scale: 0, 
     duration: 1, 
});


$(document).ready(function(){
     $('.owl-carousel').owlCarousel({
       loop: true,
       margin: 20,
       responsiveClass: true,
       responsive: {
         0: {
           items: 1,
           nav: false
         },
         600: {
           items: 3,
           nav: false
         },
         1000: {
           items: 3,
           nav: true,
           loop: false
         }
       }
     });

     // $('.owl-dots').css("display","none");
   });


   function changeColor(button) {
       var currentColor = button.style.backgroundColor;

       if (currentColor === 'black') {
           button.style.backgroundColor = '#ffffff';
           button.style.color = 'blue';
       } else {
           button.style.backgroundColor = 'black';
           button.style.color = 'white';
       }
   }

   function changeColorBtn1() {
       var btn1 = document.querySelector('.btn1');
       var currentColor = btn1.style.backgroundColor;

       if (currentColor === 'black') {
           btn1.style.backgroundColor = '#ffffff';
           btn1.style.color = 'blue';
       } else {
           btn1.style.backgroundColor = 'black';
           btn1.style.color = 'white';
       }
   }